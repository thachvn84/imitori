﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace App2
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class LevelSelect : ContentPage
	{
		public LevelSelect ()
		{
			InitializeComponent ();

            Content = BuildView();

            Layout BuildView()
            {
                StackLayout stackHeaderInv = new StackLayout()
                {
                    Padding = new Thickness(0, 10),
                    HorizontalOptions = LayoutOptions.FillAndExpand,
                    BackgroundColor = Xamarin.Forms.Color.Azure,
                };

                Button btnComplete = new Button()
                {
                    Text = "Order Completed",
                    HorizontalOptions = LayoutOptions.Center,
                };


                StackLayout stackAll = new StackLayout()
                {
                    Padding = 0,
                    Spacing = 0,
                    Children =
                    {
                        stackHeaderInv,
                        btnComplete,
                    }
                };

                return stackAll;

            }
            
		}
	}
}